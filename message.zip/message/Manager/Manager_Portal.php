 <?php
		include('core/init.inc.php');
 ?>
 <div id="wrap" style = "position:absolute;left:0px;right:0px">
	<?php
		include($include_file);
	?>
</div>

	
