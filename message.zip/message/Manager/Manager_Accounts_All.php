<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
  <link rel="stylesheet" href="man.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-default" >
  <div class="container-fluid" style="background-color:#030303;height:100px">
    <div class="navbar-header col-md-6 text-center">
      <h1 style="color:white;margin-top:30px">Welcome --name--</h1>
    </div>
    <ul class="nav navbar-nav " style=" margin-left:200px;padding-top:30px;color:white">
      <li><a href="#">Home</a></li>
      <li><a href="Manager_profile.php">Profile</a></li>
      <li><a href="#">Portal</a></li>
      <li><i class="material-icons" style="margin-top:10px; margin-right:10px;color:white">sms</i></li>
      <li><img src="pic.jpg" height="40px" width="40px" ></li>
      <li><a href="#">Signout</a>
    </ul>
  </div>
  </nav>
  <div class="container">
    <div class="row">
      <div class="col-md-3 text-center" style="left:-75px;margin-top:-21px;background-color:#e0e0e0;z-index:100;height:100%">
        <div class="list-group" style="margin-right:-15px;margin-left:2px">
    <a href="#" class="list-group-item"><h4>Employee</h4></a>
    <a href="#" class="list-group-item"><h4>Customer</h4></a>
    <a href="Manager_Accounts_Summary.php" class="list-group-item active"><h4>Accounts</h4></a>
    <a href="#" class="list-group-item"><h4>Supply</h4></a>
    <a href="#" class="list-group-item"><h4>Products</h4></a>
    <a href="#" class="list-group-item"><h4>Analysis</h4></a>
    <a href="#" class="list-group-item"><h4>Contact</h4></a>
  </div>
      </div>
       <div class="col-md-9 container">
       
    <ul class="nav nav-tabs nav-justified" style="margin-left:-105px;margin-top:-21px">
    <li ><a href="Manager_Accounts_Summary.php">Summary</a></li>
    <li class="active"><a href="#">All transactions</a></li>
    <li><a href="Manager_Accounts_Filters.php">Filters</a></li>
  </ul>
      
      </div>
  </div>

</body>
</html>