<?php
$errors = array();
$servername = "localhost";
	$username = "root";
	$password = '';
	$db = "supermarket";
	
	$conn = new mysqli($servername, $username, $password, $db);
	
	if($conn->connect_error)
		die("Connection Failed:" . $conn->connect_error);
	$sql1 = "SELECT `message_date` FROM `conversations_messages`";
	$result1 = $conn->query($sql1);
	while($row1 = $result1->fetch_assoc())
	{
		$message_date = $row1["message_date"];
		if($result1 != NULL)
		{
			$sql2 = "SELECT `conversation_last_view` FROM `conversations_members`";
			$result2 = $conn->query($sql2);
			while($row2 = $result2->fetch_assoc())
			{
				$conversation_last_view = $row2["conversation_last_view"];
				if(($message_date - $conversation_last_view) >= 0)
				{
					echo "<script> dot = document.getElementById('dot');
					dot.style.color = 'red'; </script>" ;
		
				}
				else
				{
					echo "<script> dot = document.getElementById('dot');
					dot.style.color = 'white'; </script>"; 	
				}
			}
		
		}
	}

if(isset($_GET['delete_conversation']))
{
	if(validate_conversation_id($_GET['delete_conversation']) === false)
	{
		$errors[] = 'Invalid Conversation ID';
	}

	if(empty($errors))
	{
		delete_conversation($_GET['delete_conversation']);
	}
}
$conversations = fetch_conversation_summary();

if(empty($conversations))
{
	$errors[] = "You have no messages";
}
if(empty($errors) === false)
{
	foreach($errors as $error)
	{
		echo '<div class="msg error">',$error,'</div>';
	}
}
?>
<div class="action">
	<a href="index.php?page=new_conversation">New Conversation</a>
	<a href="index.php?page=logout">Logout</a>
</div>

<div class="conversations">
	<?php
		foreach ($conversations as $conversation) 
		{
			?>
			<div class="conversation <?php if($conversation['unread_messages']) echo 'unread'; ?>">
				<h2>
					<a href ="index.php?page=inbox&amp;delete_conversation=<?php echo $conversation['id']; ?>">[x]</a>
					<a href="index.php?page=view_conversation&amp;conversation_id=<?php echo $conversation['id']; ?>"><?php echo $conversation['subject']; ?></a>
				</h2>
				<p>Last Reply: <?php echo date('d/m/y H:i:s', $conversation['last_reply']); ?></p>
			</div>
			<?php
		}
	?>

</div>
