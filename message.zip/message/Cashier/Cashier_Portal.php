
<?php
        if($_COOKIE['id'] != '103') 
			include('core/cashierinit.inc.php');
		//elseif($_COOKIE['id'] == '103')
		//	include('core/init.inc.php');
		else
			header('location:validation.php');
 ?>
 <div id="wrap" style = "position:absolute;left:0px;right:0px">
	<?php
		include($include_file);
	?>
</div>
    