<?php
echo "<h1>Please <a href=\"login.php\">Sign in</a></h1>"
?>