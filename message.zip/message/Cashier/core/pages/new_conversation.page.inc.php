<?php
	$con=mysqli_connect("localhost","root","","supermarket");
	if(isset($_POST['to'],$_POST['subject'],$_POST['body']))
	{
		$errors = array();

		if(empty($_POST['to']))
		{
			$errors[] = "You must enter at least one name.";
		} 
		else if(preg_match('#^[a-z0-9, ]+$#i', $_POST['to']) ==0)
		{
			$errors[] = "The list of names you gave does not look valid.";
		}

		//broadcast message ONLY FOR EMPLOYEE
		//assuming 101 is a manager
		/*else if(strcmp('all' , $_POST['to']) == 0)
		{
			$sql = "SELECT E_ID from employee
					WHERE E_ID != 101";

			$result = mysqli_query($con,$sql);
			$user_ids[] = array();
			$i = 0;
			while(($row = mysqli_fetch_assoc($result)) !== NULL)
			{
				$user_ids[$i] = $row['E_ID'];
				$i = $i + 1;
			}
		}*/

		//FOR EMPLOYEE == CAN SEND ONLY TO MANAGER
		else
		{
			
			if($_POST['to'] != 101)
			{
				$errors[] = "Can send only to Manager(101)";
			}

			else
			{
				$user_ids = $_POST['to'];
			}
		}

		if(empty($_POST['subject']))
		{
			$errors[] = "The subject cannot be empty.";
		}		

		if(empty($_POST['body']))
		{
			$errors[] = "The body cannot be empty.";
		}

		if(empty($errors))
		{
			create_conversation(array_unique($user_ids),$_POST['subject'],$_POST['body']);
		}
	}

if(isset($errors))
{
	if(empty($errors))
	{
		echo '<div class="msg success">Your message has been sent! <a href = "index.php?page=inbox">Return to your Inbox</a></div>';
	}
	else
	{
		foreach ($errors as $error) 
		{
			echo '<div class="msg error">',$error,'</div>';
		}
	}
}
?>

<form action="" method="POST">
	<div>
		<label for="to">To</label>
		<input type="text" name="to" id="to" value="<?php if (isset($_POST['to'])) echo htmlentities($_POST['to']); ?>"/>
	</div>
	<div>
		<label for="subject">Subject</label>
		<input type="text" name="subject" id="subject" value="<?php if (isset($_POST['subject'])) echo htmlentities($_POST['subject']); ?>"/>
	</div>
	<div>
		<textarea name="body" rows="20" cols="95"><?php if (isset($_POST['body'])) echo htmlentities($_POST['body']); ?></textarea>
	</div>
	<div>
		<input type="submit" value="Send"/>
	</div>
</form>