<?php
	session_destroy();
?>
<div class="msg success">You have logged out.</div>
