<?php

function validate_credentials($user_name,$user_password)
{
	return $user_name;
}

?>