<?php

function fetch_conversation_summary()
{
	$con=mysqli_connect("localhost","root","","supermarket");

	$sql = "SELECT conversations.conversation_id, 
				   conversations.conversation_subject,
				   MAX(conversations_messages.message_date) AS conversation_last_reply,
				   MAX(conversations_messages.message_date) > conversations_members.conversation_last_view AS conversation_unread
			FROM conversations
			LEFT JOIN conversations_messages ON conversations.conversation_id = conversations_messages.conversation_id
			INNER JOIN conversations_members ON conversations.conversation_id = conversations_members.conversation_id
			WHERE conversations_members.E_ID =".$_COOKIE['id']."
			AND conversations_members.conversation_deleted = 0
			GROUP BY conversation_id
			ORDER BY conversation_last_reply DESC";

	$result = mysqli_query($con,$sql);

	$conversations = array();

	while(($row = mysqli_fetch_assoc($result)) !== NULL)
	{
		$conversations[] = array(
			'id'=> $row['conversation_id'], 
			'subject'=> $row['conversation_subject'], 
			'last_reply'=> $row['conversation_last_reply'],
			'unread_messages' => ($row['conversation_unread'] == 1),
			);
		//echo $row['conversation_id'];
	}

	return $conversations;
}

function fetch_conversation_messages($conversation_id)
{
	$con=mysqli_connect("localhost","root","","supermarket");
	$conversation_id = (int)$conversation_id;

	$sql = "SELECT 
				conversations_messages.message_date,
				conversations_messages.message_date > conversations_members.conversation_last_view AS message_unread,
				conversations_messages.message_text,
				employee.Name
			FROM conversations_messages
			INNER JOIN employee ON conversations_messages.E_ID = employee.E_ID
			INNER JOIN conversations_members ON conversations_messages.conversation_id = conversations_members.conversation_id
			WHERE conversations_messages.conversation_id = {$conversation_id}
			AND conversations_members.E_ID =".$_COOKIE['id']."
			ORDER BY conversations_messages.message_date DESC";

	$result = mysqli_query($con,$sql);
	$messages = array();

	while(($row = mysqli_fetch_assoc($result)) !== NULL)
	{
		$messages[] = array(
			'date' => $row['message_date'],
			'unread' => $row['message_unread'],
			'text' => $row['message_text'],
			'user_name' => $row['Name'],
		);
	}

	return $messages;
}

function update_conversation_last_view($conversation_id)
{
	$con=mysqli_connect("localhost","root","","supermarket");
	$conversation_id = (int)$conversation_id;

	$sql = "UPDATE conversations_members
			SET conversation_last_view = UNIX_TIMESTAMP()
			WHERE conversation_id = {$conversation_id}
			AND E_ID =".$_COOKIE['id']."";

	mysqli_query($con,$sql);
}



function create_conversation($user_ids,$subject,$body)
{
	$con=mysqli_connect("localhost","root","","supermarket");
	$subject = mysqli_real_escape_string($con,htmlentities($subject));
	$body = mysqli_real_escape_string($con,htmlentities($body));

	mysqli_query($con,"INSERT INTO conversations (conversation_subject) VALUES ('{$subject}')");
	$conversation_id = mysqli_insert_id($con);

	$sql="INSERT INTO conversations_messages (conversation_id, E_ID , message_date, message_text) VALUES ({$conversation_id},".$_COOKIE['id']." ,UNIX_TIMESTAMP(),'{$body}')";

	mysqli_query($con,$sql);

	$values = array("({$conversation_id},".$_COOKIE['id'].",UNIX_TIMESTAMP(),0)");

	

	foreach ($user_ids as $user)
	{
		$user = (int)$user;
		$values[] = "({$conversation_id},{$user},0,0)";
	}

	$sql="INSERT INTO conversations_members (conversation_id, E_ID, conversation_last_view, conversation_deleted) VALUES " . implode(", ",$values);
	mysqli_query($con,$sql);
}

function mysqli_result($res,$row=0,$col=0)
{ 
    $numrows = mysqli_num_rows($res); 
    if ($numrows && $row <= ($numrows-1) && $row >=0){
        mysqli_data_seek($res,$row);
        $resrow = (is_numeric($col)) ? mysqli_fetch_row($res) : mysqli_fetch_assoc($res);
        if (isset($resrow[$col])){
            return $resrow[$col];
        }
    }
    return false;
}

//checks to see if the given user is a member of the given convo
function validate_conversation_id($conversation_id)
{
	$con=mysqli_connect("localhost","root","","supermarket");
	$conversation_id = (int)$conversation_id;

	$sql = "SELECT COUNT(1)
			FROM conversations_members
			WHERE conversation_id = {$conversation_id}
			AND E_ID =".$_COOKIE['id']."
			AND conversation_deleted = 0";

	$result = mysqli_query($con,$sql);

	return (mysqli_result($result,0) == 1);
}

function add_conversation_message($conversation_id,$text)
{
	$con=mysqli_connect("localhost","root","","supermarket");
	$conversation_id = (int)$conversation_id;
	$text = mysqli_real_escape_string($con,htmlentities($text));

	$sql = "INSERT INTO conversations_messages (conversation_id, E_ID, message_date, message_text)
			VALUES ({$conversation_id}, {$_SESSION['user_id']},UNIX_TIMESTAMP(),'{$text}')";

	mysqli_query($con,$sql);

	//mysqli_query("UPDATE conversations_members SET conversation_deleted = 0 WHERE conversation_id= {$conversation_id}");

}

function delete_conversation($conversation_id)
{
	$con=mysqli_connect("localhost","root","","supermarket");
	$conversation_id = (int)$conversation_id;

	$sql= "SELECT DISTINCT conversation_deleted
		   FROM conversations_members
		   WHERE E_ID !=".$_COOKIE['id']."
		   AND conversation_id = {$conversation_id}";

	$result = mysqli_query($con,$sql);
	if(mysqli_num_rows($result) == 1 && mysqli_result($result,0) == 0 )
	{
		mysqli_query($con,"DELETE FROM conversations WHERE conversation_id = {$conversation_id}");
		mysqli_query($con,"DELETE FROM conversations_members WHERE conversation_id = {$conversation_id}");
		mysqli_query($con,"DELETE FROM conversations_messages WHERE conversation_id = {$conversation_id}");
	}

	else
	{
		$sql = "UPDATE conversations_members
				SET conversation_deleted = 1
				WHERE conversation_id = {$conversation_id}
				AND user_id =".$_COOKIE['id']."";

		mysqli_query($con,$sql);
	}
}	

?>