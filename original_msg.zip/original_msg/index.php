<?php
include('core/init.inc.php');
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Message</title>
		<link rel="stylesheet" type="text/css" href="ext/css/main.css"/>
	</head>
	<body>
		<div id="wrap">
			<?php
				include($include_file);
			?>
		</div>
	</body>
</html>