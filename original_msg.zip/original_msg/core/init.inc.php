<?php
//check that user enters the correct page
$core_path = dirname(__FILE__);
if(empty($_GET['page']) || in_array("{$_GET['page']}.page.inc.php",scandir("{$core_path}/pages")) == false)
{
	header('HTTP/1.1 404 NOT FOUND');
	header('Location: index.php?page=inbox');
	die();
}

//check if it is a valid user.
session_start();

$conn = new mysqli("localhost", "root", "", "supermarket");

include("{$core_path}/inc/user.inc.php");
include("{$core_path}/inc/private_message.inc.php");

if (isset($_POST['user_name'], $_POST['user_password']))
{
	if(($user_id = validate_credentials($_POST['user_name'] , $_POST['user_password']))!== false)
	{
		$_SESSION['user_id'] = $user_id;
		header('Location: index.php?page=inbox');
		die();
	}
}

//check if user has logged in ; if not redirect to login page
if(empty($_SESSION['user_id']) && $_GET['page']!== 'login')
{
	header('HTTP/1.1 403 FORBIDDEN');
	header('Location: index.php?page=login');

	die();
}

$include_file = "{$core_path}/pages/{$_GET['page']}.page.inc.php";

?>